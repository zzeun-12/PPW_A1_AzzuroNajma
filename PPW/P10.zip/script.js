alert("Nah, kalau yang ini dari metode Eksternal")

